# AshBrowser X — PWA Edition

A customizable browser-style start page and Android app hub for ChromeOS.

## Deploy to Cloudflare Pages (Direct Upload)
1. Extract this ZIP.
2. In Cloudflare Dashboard, open **Workers & Pages** → **Create application** → **Pages** → **Drag and drop your files**.
3. Upload the extracted folder contents (the folder containing `index.html`, not the ZIP).
4. Deploy. Use the `*.pages.dev` HTTPS URL.
5. Open the URL in ChromeOS Chrome → menu → **Install page as app**.

For updates, create a new deployment of the same Pages project with the updated files.

## Features
- Google search and URL detection
- Custom shortcuts
- Wallpaper upload stored locally in IndexedDB
- Accent colors and dark/light/AMOLED themes
- APK file library stored locally in IndexedDB, with download and remove
- PWA manifest and offline app-shell cache

## Important Android limitation
This is a PWA. Browser-based web apps cannot install, execute, or emulate Android APK files, nor can they directly enumerate or launch Android apps installed by ChromeOS. The APK Library only stores and organizes files inside this browser profile. To install/run Android apps, use ChromeOS's supported Google Play Store / Android app features. The AshDroid workspace preview is explicitly a UI preview, not an Android virtual machine.

## Data and privacy
Shortcuts/settings use localStorage. APK files and wallpaper are stored in this browser profile's IndexedDB. Clearing site data may erase them. Files are not uploaded to Cloudflare by this app.
